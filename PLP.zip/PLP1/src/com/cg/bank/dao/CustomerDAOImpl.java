package com.cg.bank.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bank.dto.Customer;
import com.cg.bank.dto.Transactions;

@Repository("customerdao")
public class CustomerDAOImpl implements ICustomerDAO{
	@PersistenceContext
	EntityManager em;
	
/*	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	Create Account(Customer customer)
	 - Input Parameters	:	Customer
	 - Return Type		:	void
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Adding customer data to the database
	 ********************************************************************************************************//*
	
	@Override
	@Transactional
	public void createAccount(Customer customer) {
		Transactions trans = new Transactions();
		em.persist(customer);	
		trans.setMobileNo(customer.getMobileNo());
		trans.setAmount(0);
		trans.setBalance(customer.getInitialBalance());
		trans.setCd("Credit(New Acc)");
		Date date = new Date();
		trans.setDate(String.valueOf(dateFormat.format(date)));
		em.persist(trans);
		em.flush();
	}
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	deposit(String mobileNo, double amount)
	 - Input Parameters	:	mobileNo and amount
	 - Return Type		:	double
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Adding money to the Balance
	 ********************************************************************************************************//*
	
	@Override
	@Transactional
	public double deposit(String mobileNo, double amount){
		Transactions trans = new Transactions();
		Customer c = em.find(Customer.class, mobileNo);
		double amt = c.getInitialBalance();
		amt = amt+amount;
		c.setInitialBalance(amt);
		trans.setMobileNo(mobileNo);
		trans.setAmount(amount);
		trans.setBalance(amt);
		trans.setCd("Credit");
		Date date = new Date();
		trans.setDate(String.valueOf(dateFormat.format(date)));
		em.persist(trans);
		em.flush();
		return amt;
	}
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	withdraw(String mobileNo, double amount)
	 - Input Parameters	:	mobileNo and amount
	 - Return Type		:	double
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Withdrawing money to the Balance
	 ********************************************************************************************************//*

	@Override
	@Transactional
	public double withdraw(String mobileNo, double amount) {
		Transactions trans = new Transactions();
		Customer c = em.find(Customer.class, mobileNo);
		double amt =c.getInitialBalance();
		amt=amt-amount;
		c.setInitialBalance(amt);
		trans.setMobileNo(mobileNo);
		trans.setAmount(amount);
		trans.setBalance(amt);
		trans.setCd("Debit");
		Date date = new Date();
		trans.setDate(String.valueOf(dateFormat.format(date)));
		em.persist(trans);
		em.flush();
		return amt;
	}
	
	//------------------------ 1. Wallet Application --------------------------
		*//*******************************************************************************************************
		 - Function Name	:	checkBalance(String mobileNo)
		 - Input Parameters	:	mobileNo
		 - Return Type		:	double
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/14/2018
		 - Description		:	Checking the balance
		 ********************************************************************************************************//*

	@Override
	public double checkBalance(String mobileNo) {
		Customer c = em.find(Customer.class, mobileNo);
		return c.getInitialBalance();
	}
	
		//------------------------ 1. Wallet Application --------------------------
		*//*******************************************************************************************************
		 - Function Name	:	accountVal(String mobileNo)
		 - Input Parameters	:	mobileNo
		 - Return Type		:	boolean
		 - Author			:	CAPGEMINI
		 - Creation Date	:	11/14/2018
		 - Description		:	Checking if account exists
		 ********************************************************************************************************//*

	@Override
	public boolean accountVal(String mobileNo) {
		Customer c1= em.find(Customer.class, mobileNo);
		if(c1 != null)
			return true;
		else
			return false;		
	}
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	fundTransfer(String mobno1, double amt, String mobno2)
	 - Input Parameters	:	mobno1, amt, mobno2
	 - Return Type		:	double
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Fund transfer from one account to other
	 ********************************************************************************************************//*

	@Override
	@Transactional
	public double fundTransfer(String mobno1, double amt, String mobno2) {
		Transactions trans = new Transactions();
		Customer c= em.find(Customer.class, mobno1);
		Customer c1= em.find(Customer.class, mobno2);
		double amount1 = c.getInitialBalance() - amt;
		double amount2 = c1.getInitialBalance() + amt;
		c.setInitialBalance(amount1);
		c1.setInitialBalance(amount2);
		Transactions trans1 = new Transactions();
		trans.setMobileNo(mobno1);
		trans.setAmount(amt);
		trans.setBalance(amount1);
		trans.setCd("Debit(F)");
		Date date = new Date();
		trans.setDate(String.valueOf(dateFormat.format(date)));
		trans1.setMobileNo(mobno2);
		trans1.setAmount(amt);
		trans1.setBalance(amount2);
		trans1.setCd("Credit(F)");
		trans1.setDate(String.valueOf(dateFormat.format(date)));
		em.persist(trans);
		em.persist(trans1);
		em.flush();		
		return amount1;
	}
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	withdrawVal(String mobileNo, double amount)
	 - Input Parameters	:	mobileNo and amount
	 - Return Type		:	boolean
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Checks if balance after withdraw/fund transfer is greater than equal to 1
	 ********************************************************************************************************//*

	@Override
	public boolean withdrawVal(String mobileNo, double amount) {
		Customer c = em.find(Customer.class, mobileNo);
		double amt = c.getInitialBalance();
		if(amt-amount<1)
			return false;
		else
			return true;
	}
	
	//------------------------ 1. Wallet Application --------------------------
	*//*******************************************************************************************************
	 - Function Name	:	getTransList(String mobileNo)
	 - Input Parameters	:	mobileNo
	 - Return Type		:	List<Transactions>
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/14/2018
	 - Description		:	Retrieves list of transactions of a particular mobile number from transactions table 
	 ********************************************************************************************************//*

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		String qr = "select trans from Transactions trans where mobileNo ="+mobileNo+" order by id";
		TypedQuery<Transactions> query = em.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
	}*/

	@Override
	public List<Customer> getAllorders() {
		String qr = "select trans from Customer trans";
		TypedQuery<Customer> query = em.createQuery(qr, Customer.class);
		List<Customer> list = query.getResultList();
		return list;	
	}
}
