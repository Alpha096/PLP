package com.cg.plp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.plp.dto.Order;
import com.cg.plp.service.PlpService;
import com.cg.plp.service.PlpServiceImpl;

@Controller
public class PlpController {
	
	@Autowired
	PlpService service;
	@RequestMapping(value="/AllOrders")
	public ModelAndView getAllCust(@ModelAttribute("my") Order order) {
		List<Order> list = service.getAllOrders();
		return new ModelAndView("AllOrder", "list", list);
	}
	


}
