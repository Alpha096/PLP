package com.cg.plp.service;

import java.util.List;

import com.cg.plp.dto.Order;

public interface PlpService {

	public List<Order> getAllOrders();

}
