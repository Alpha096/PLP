package com.cg.plp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.plp.dao.PlpDao;
import com.cg.plp.dto.Order;

public class PlpServiceImpl implements PlpService{

	@Autowired
	PlpDao dao;
	
	@Override
	public List<Order> getAllOrders() {
		// TODO Auto-generated method stub
		return dao.getAllOrders();
	}
	
	

}
