package com.cg.plp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.plp.dto.Order;


@Repository("dao")
public class PlpDaoImpl implements PlpDao{
	@PersistenceContext
	EntityManager em;

	@Override
	public List<Order> getAllOrders() {
		String qr = "select trans from Transactions trans";
		TypedQuery<Order> query = em.createQuery(qr, Order.class);
		List<Order> list = query.getResultList();
		return list;	
	}

}
