package com.cg.plp.dao;

import java.util.List;

import com.cg.plp.dto.Order;

public interface PlpDao {

	List<Order> getAllOrders();

}
